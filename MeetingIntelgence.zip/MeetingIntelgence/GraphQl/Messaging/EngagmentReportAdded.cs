﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MeetingIntelgence.GraphQl.Messaging
{
    public class EngagmentReportAdded
    {
        public string MeetingId { get; set; }

    }
}
