﻿namespace MeetingIntelgence.Data.Entities
{
    public class RaiseHandsData
    {
        public RaiseHandsInterval[] RaiseHandsIntervals;
        public int TotalCount;
    }
}