﻿using System;

namespace MeetingIntelgence.Data.Entities
{
    public class RaiseHandsInterval
    {
        public DateTime StartTimeUTC { get; set; }
        public DateTime EndTimeUTC { get; set; }
    }
}